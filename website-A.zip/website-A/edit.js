    window.onload = function() {
      const urlParams = new URLSearchParams(window.location.search);
      const roomId = urlParams.get('room_id');

      fetch(`get_room.php?room_id=${roomId}`)
        .then(response => response.json())
        .then(data => {
          document.getElementById('room_id').value = data.room_id;
          document.getElementById('roomType').value = data.room_Type;
          document.getElementById('roomCapacity').value = data.room_Capacity;
          document.getElementById('roomAvailable').value = data.room_Available;

          const amenities = data.room_Amenities.split(',');
          amenities.forEach(amenity => {
            const checkbox = document.querySelector(`input[name="roomAmenities[]"][value="${amenity.trim()}"]`);
            if (checkbox) {
              checkbox.checked = true;
            }
          });

          document.getElementById('roomRate').value = data.room_Rate;
        })
        .catch(error => console.error('Error fetching room data:', error));
    };