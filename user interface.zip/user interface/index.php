<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Corrected favicon link -->
  <link rel="icon" type="image/png" href="img/new_logo.png">
  <!-- Check if these paths are correct and the files are being loaded -->
  <link rel="stylesheet" href="css/booking.css">
  <link rel="stylesheet" href="css/draft.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer">
  <title>VILLASTAR</title>
  <style>
  .sticky {
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
    }

    .navbar {
      background-color: #f4eeed;
      height: 70px;
      display: flex;
      align-items: center;
      font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
      padding: 0 40px;
    }

    .company-name {
      flex: 1;
      color: #74775a;
      font-size: 18px;
      font-weight: bold;
    }

    .border {
      height: 1px;
      width: 100%;
      margin: 0 auto;
      display: block;
      background-color: #999b84;
      top: 1;
    }

    .main-container {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      margin-top: 370px;
    }

    .container2 {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  min-height: 100vh; /* Ensure the container takes at least the full height of the viewport */
  padding: 20px;
}

    .left-tabs {
  display: flex;
  flex-wrap: wrap;
  margin-top: 20px;
}

/* Styles for the tab radio input */
.tabs_radio {
  display: none;
}

/* Styles for the tab labels */
.tabs_label {
  padding: 10px 16px;
  cursor: pointer;
  color: #74775A;
}

/* Styles for the tab content */
.tabs_content {
  color: #74775A;
  margin-top: 10px;
  order: 1;
  width: 100%;
  line-height: 1.5;
  font-size: 0.9em;
  display: none;
}

/* Styles for the card */
.card {
  display: flex;
  margin-bottom: 20px;
  border: 1px solid #74775A;
  border-radius: 5px;
  overflow: hidden;
  background-color: #fff;
  color: #74775A;
  font-size: 16px;
  position: relative;
}

/* Styles for the card image */
.card-img {
  height: 300px;
  object-fit: cover;
}

/* Styles for the card text */
.card-text {
  padding: 5px 0px 0 15px;
}

/* Styles for the room name */
.pname {
  margin: 5px 0;
  color: #74775A;
}

/* Styles for the room price */
.price {
  margin: 5px 0;
  color: #74775A;
}

/* Styles for the column on the right side of the card */
.column-right1 {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

/* Styles for the button */
.book-button {
  background-color: #74775A;
  color: #fff;
  border: none;
  padding: 8px 15px;
  border-radius: 20px;
  cursor: pointer;
  margin-top: 10px;
}

/* Hover style for the button */
.book-button:hover {
  background-color: #b0b67a;
}
  </style>
</head>
<body>  

<div class="sticky">
  <div class="navbar">
    <div class="company-name"><a href="index.php"><img id="logo" src="img/logo1.png"></a></div>
  </div>
  <div class="border"></div>
</div>

<div class="main-container">
  <section class="container2">
    <header id="title">White Villas Resort</header>
    <p class="desc1">Search for a room that fits your needs!</p>

    <form action="index.php" method="GET" class="form">
      <div class="column center-align">
        <div class="input-box program">
          <div class="select-box">
            <select id="select1" name="room_type" required>
              <option hidden>Room Type</option>
              <option value="Single Room">Single Room</option>
              <option value="Twin Room">Twin Room</option>
              <option value="Beachside Room">Beachside Room</option>
              <option value="Deluxe Room">Deluxe Room</option>
              <option value="Villa">Villa</option>
            </select>
          </div>
        </div>
      </div>
      <div class="column center-align">
        <input class="buttons search-button" type="submit" value="Search for Rooms"/>
      </div>
    </form>

    <div class="border"></div>

    <div class="left-tabs">
      <input type="radio" class="tabs_radio" name="tabs-example" id="tab1" checked>
      <label for="tab1" class="tabs_label">Room choices</label>
      <div class="tabs_content">
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "siquijordb";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $room_type = isset($_GET['room_type']) ? $_GET['room_type'] : '';
        $sql = "SELECT * FROM rooms";
        if (!empty($room_type)) {
            $sql .= " WHERE room_Type LIKE '%$room_type%'";
        }
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo '<div class="card">';
                echo '<img src="' . $row['room_Image'] . '" alt="' . $row['room_Type'] . '" class="card-img">';
                echo '<div class="card-text">';
                echo '<h3 class="pname">' . $row['room_Type'] . '</h3>';
                echo '<h3 class="price">₱ ' . $row['room_Rate'] . ' per night</h3>';
                echo '<table>';
                echo '<tr>';
                echo '<td>Amenities</td>';
                echo '<td>' . $row['room_Amenities'] . '</td>';
                echo '</tr>';
                echo '<tr>';
                echo '<td>Room Capacity</td>';
                echo '<td>' . $row['room_Capacity'] . ' PAX</td>';
                echo '</tr>';
                echo '</table>';
                echo '<button class="book-button">Select Room</button>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "<p>No rooms found</p>";
        }
        $conn->close();
        ?>
      </div>
    </div>
  </section>
</div>

<script src="booking_form.js"></script>

</body>
</html>